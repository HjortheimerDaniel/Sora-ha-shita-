#pragma once
#include "Struct.h"
#include "Novice.h"

void Jump(char* keys, char* preKeys, PlayerStruct& player);