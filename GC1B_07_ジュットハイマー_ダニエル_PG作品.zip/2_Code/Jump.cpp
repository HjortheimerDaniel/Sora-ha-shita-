#include "Jump.h"

void Jump(char* keys, char* preKeys, PlayerStruct& player) {

	
}